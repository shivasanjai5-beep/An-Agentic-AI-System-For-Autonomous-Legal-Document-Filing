export interface ChatResponse {
  response: string;
  session_id: string;
  generated_html?: string;
}

export type IssueType = 
  | "legal_notice" 
  | "rental_agreement"
  | "consumer_complaint"
  | "cheque_bounce"
  | "rti_application"
  | "general_query";

class GeminiService {
  private baseUrl = "http://localhost:8000";
  private sessionId: string;
  private currentIssueType: IssueType | null = null;

  constructor() {
    this.sessionId = "s_" + Math.random().toString(36).substring(2, 15);
  }

  setIssueType(issueType: IssueType) {
    this.currentIssueType = issueType;
  }

  async sendMessage(message: string): Promise<ChatResponse> {
    try {
      const res = await fetch(`${this.baseUrl}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          session_id: this.sessionId,
          message: message,
          issue_type: this.currentIssueType, // Backend expects "issue_type"
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.detail || "Failed to get response from backend");
      }

      const data = await res.json();

      return {
        response: data.response || "",
        session_id: data.session_id || this.sessionId,
        generated_html: data.generated_html,
      };

    } catch (error) {
      console.error("Error sending message:", error);
      throw error;
    }
  }

  async downloadDocument(htmlContent: string, format: "pdf" | "docx") {
    try {
      const res = await fetch(`${this.baseUrl}/download/${format}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ html_content: htmlContent }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.detail || `Failed to generate ${format}`);
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `legal_document.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error(`Error downloading ${format}:`, error);
      throw error;
    }
  }

  getSessionId(): string {
    return this.sessionId;
  }

  async clearSession(): Promise<void> {
    try {
      await fetch(`${this.baseUrl}/sessions/${this.sessionId}`, {
        method: "DELETE",
      });
    } catch (error) {
      console.error("Error clearing session:", error);
    }
    // Generate a new session ID regardless of whether the API call succeeded
    this.sessionId = "s_" + Math.random().toString(36).substring(2, 15);
    this.currentIssueType = null;
  }
}

export const geminiService = new GeminiService();
