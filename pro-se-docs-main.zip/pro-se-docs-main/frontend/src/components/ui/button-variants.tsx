import { Button } from "./button";
import { ButtonProps } from "./button";

export function HeroButton({ children, ...props }: ButtonProps) {
  return (
    <Button
      {...props}
      className="bg-gradient-primary text-primary-foreground hover:opacity-90 hover:shadow-lg transition-all duration-300 text-lg px-8 py-6 h-auto animate-pulse-glow"
    >
      {children}
    </Button>
  );
}

export function SecondaryButton({ children, ...props }: ButtonProps) {
  return (
    <Button
      {...props}
      variant="outline"
      className="border-2 border-primary text-primary hover:bg-primary/10 transition-all duration-300"
    >
      {children}
    </Button>
  );
}

export function AccentButton({ children, ...props }: ButtonProps) {
  return (
    <Button
      {...props}
      className="bg-accent text-accent-foreground hover:bg-accent/90 transition-all duration-300"
    >
      {children}
    </Button>
  );
}
