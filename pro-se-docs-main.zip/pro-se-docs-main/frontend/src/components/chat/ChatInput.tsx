import { useState, useEffect } from "react";
import { Send, Paperclip, Mic, MicOff, AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useSpeech } from "@/hooks/useSpeech";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
}

export const ChatInput = ({ onSend, disabled }: ChatInputProps) => {
  const [message, setMessage] = useState("");
  
  const { 
    isListening,
    isProcessing, 
    transcript, 
    startListening, 
    stopListening, 
    resetTranscript,
    error: speechError,
    supported: speechSupported 
  } = useSpeech();

  // Show error toast when speech error occurs
  useEffect(() => {
    if (speechError) {
      toast.error(speechError);
    }
  }, [speechError]);

  // Sync speech transcript to message input (append only)
  useEffect(() => {
    if (transcript) {
      setMessage(prev => {
        // Avoid duplicate appends if effect runs multiple times
        if (prev.endsWith(transcript)) return prev;
        return prev + (prev ? " " : "") + transcript;
      });
      resetTranscript();
    }
  }, [transcript, resetTranscript]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !disabled && !isListening && !isProcessing) {
      onSend(message.trim());
      setMessage("");
    }
  };

  const toggleListening = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="border-t bg-background p-4">
      <form onSubmit={handleSubmit} className="flex gap-2 items-end">
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="flex-shrink-0"
        >
          <Paperclip className="w-5 h-5" />
        </Button>

        <Textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isListening ? "Listening... (Click stop to transcribe)" : isProcessing ? "Transcribing..." : "Type your message... (Shift+Enter for new line)"}
          disabled={disabled || isProcessing}
          className={cn(
            "min-h-[60px] max-h-[200px] resize-none",
            isListening && "border-red-500/50 bg-red-50/10",
            isProcessing && "bg-muted animate-pulse"
          )}
          rows={2}
        />

        <div className="relative">
          {speechSupported && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className={cn(
                "flex-shrink-0 transition-all duration-200", 
                isListening ? "text-red-500 hover:text-red-600 bg-red-50 hover:bg-red-100" : "hover:text-primary",
                speechError && "text-destructive hover:text-destructive hover:bg-destructive/10"
              )}
              onClick={toggleListening}
              disabled={disabled || isProcessing}
              title={speechError || (isListening ? "Stop recording" : "Start voice input")}
            >
              {isProcessing ? (
                <Loader2 className="w-5 h-5 animate-spin text-primary" />
              ) : isListening ? (
                <MicOff className="w-5 h-5 animate-pulse" />
              ) : speechError ? (
                <AlertCircle className="w-5 h-5" />
              ) : (
                <Mic className="w-5 h-5" />
              )}
            </Button>
          )}
        </div>

        <Button
          type="submit"
          disabled={!message.trim() || disabled || isListening || isProcessing}
          className="flex-shrink-0 bg-gradient-primary hover:opacity-90"
          size="icon"
        >
          <Send className="w-5 h-5" />
        </Button>
      </form>
    </div>
  );
};
