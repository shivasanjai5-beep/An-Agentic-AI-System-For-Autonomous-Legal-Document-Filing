import { Button } from "@/components/ui/button";

interface QuickResponsesProps {
  responses: string[];
  onSelect: (response: string) => void;
}

export const QuickResponses = ({ responses, onSelect }: QuickResponsesProps) => {
  return (
    <div className="flex flex-wrap gap-2 mt-4">
      {responses.map((response, index) => (
        <Button
          key={index}
          variant="outline"
          size="sm"
          onClick={() => onSelect(response)}
          className="hover:bg-primary/10 hover:border-primary transition-all"
        >
          {response}
        </Button>
      ))}
    </div>
  );
};
