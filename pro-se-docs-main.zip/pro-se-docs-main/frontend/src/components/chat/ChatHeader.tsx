import { ArrowLeft, Scale } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

interface ChatHeaderProps {
  onBack?: () => void;
}

export const ChatHeader = ({ onBack }: ChatHeaderProps) => {
  const navigate = useNavigate();

  const handleLogoClick = () => {
    if (onBack) {
      onBack();
    } else {
      navigate("/");
    }
  };

  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-10">
      <div className="container flex h-14 max-w-screen-2xl items-center">
        {onBack ? (
           <Button variant="ghost" size="icon" onClick={onBack} className="mr-2">
             <ArrowLeft className="h-4 w-4" />
           </Button>
        ) : (
          <Button variant="ghost" size="icon" onClick={() => navigate("/")} className="mr-2">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        )}
        
        <div className="flex items-center gap-2 font-bold cursor-pointer" onClick={handleLogoClick}>
          <Scale className="h-5 w-5 text-primary" />
          <span>Legal Assistant</span>
        </div>
      </div>
    </header>
  );
};
