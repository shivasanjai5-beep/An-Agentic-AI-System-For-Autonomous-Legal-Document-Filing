import { Bot, User, FileDown, Volume2, Square } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import ReactMarkdown from "react-markdown";

interface ChatMessageProps {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp?: string;
  generatedHtml?: string;
  onDownload?: (html: string, format: "pdf" | "docx") => void;
  onSpeak?: () => void;
  onStop?: () => void;
  isSpeaking?: boolean;
}

export const ChatMessage = ({ 
  role, 
  content, 
  timestamp, 
  generatedHtml, 
  onDownload,
  onSpeak,
  onStop,
  isSpeaking 
}: ChatMessageProps) => {
  if (role === "system") {
    return (
      <div className="flex justify-center py-4">
        <div className="bg-success/10 text-success px-4 py-2 rounded-full text-sm font-medium">
          {content}
        </div>
      </div>
    );
  }

  const isUser = role === "user";

  return (
    <div
      className={cn(
        "flex gap-3 mb-4 animate-fade-in",
        isUser ? "flex-row-reverse" : "flex-row"
      )}
    >
      <div
        className={cn(
          "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
          isUser ? "bg-gradient-accent" : "bg-primary/10"
        )}
      >
        {isUser ? (
          <User className="w-5 h-5 text-white" />
        ) : (
          <Bot className="w-5 h-5 text-primary" />
        )}
      </div>

      <div className="flex flex-col gap-2 max-w-[80%]">
        <div
          className={cn(
            "rounded-2xl px-4 py-3 shadow-soft",
            isUser
              ? "bg-gradient-accent text-white"
              : "bg-card border"
          )}
        >
          {isUser ? (
            <p className="text-sm md:text-base leading-relaxed whitespace-pre-wrap">
              {content}
            </p>
          ) : (
            <div className="text-sm md:text-base leading-relaxed">
              <ReactMarkdown
                components={{
                  a: ({ node, ...props }) => (
                    <a
                      {...props}
                      className="text-primary underline hover:text-primary/80 font-medium"
                      target="_blank"
                      rel="noopener noreferrer"
                    />
                  ),
                  p: ({ node, ...props }) => <p {...props} className="mb-2 last:mb-0 whitespace-pre-wrap" />,
                  ul: ({ node, ...props }) => <ul {...props} className="list-disc ml-4 mb-2" />,
                  ol: ({ node, ...props }) => <ol {...props} className="list-decimal ml-4 mb-2" />,
                  li: ({ node, ...props }) => <li {...props} className="mb-1 pl-1" />,
                  strong: ({ node, ...props }) => <strong {...props} className="font-semibold" />,
                  blockquote: ({ node, ...props }) => (
                    <blockquote {...props} className="border-l-4 border-primary/20 pl-4 italic my-2" />
                  ),
                }}
              >
                {content}
              </ReactMarkdown>
            </div>
          )}
          
          {timestamp && (
            <p
              className={cn(
                "text-xs mt-2 opacity-70",
                isUser ? "text-white" : "text-muted-foreground"
              )}
            >
              {timestamp}
            </p>
          )}
        </div>
        
        {generatedHtml && onDownload && (
          <div className="flex gap-2 mt-1">
             <Button 
               variant="outline" 
               size="sm" 
               onClick={() => onDownload(generatedHtml, "docx")}
               className="gap-2"
             >
               <FileDown className="w-4 h-4" />
               Download DOCX
             </Button>
          </div>
        )}

        {!isUser && onSpeak && (
          <div className="flex gap-2 mt-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={isSpeaking ? onStop : onSpeak}
              className={cn(
                "gap-2 text-muted-foreground hover:text-primary",
                isSpeaking && "text-primary animate-pulse"
              )}
              title={isSpeaking ? "Stop reading" : "Read aloud"}
            >
              {isSpeaking ? (
                <Square className="w-4 h-4 fill-current" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
              <span className="text-xs">{isSpeaking ? "Stop" : "Listen"}</span>
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
