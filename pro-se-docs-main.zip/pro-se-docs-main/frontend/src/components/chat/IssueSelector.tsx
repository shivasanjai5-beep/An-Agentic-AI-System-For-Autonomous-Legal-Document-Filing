import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Home, AlertCircle, Banknote, FileSearch, HelpCircle } from "lucide-react";

export type IssueType = 
  | "legal_notice" 
  | "rental_agreement"
  | "consumer_complaint"
  | "cheque_bounce"
  | "rti_application"
  | "general_query";

interface IssueSelectorProps {
  onSelect: (issueType: IssueType) => void;
}

export const IssueSelector = ({ onSelect }: IssueSelectorProps) => {
  const issues = [
    {
      id: "general_query" as IssueType,
      title: "General Legal Queries",
      description: "Ask general questions about Indian law, procedures, or rights.",
      icon: <HelpCircle className="w-10 h-10 text-indigo-500 mb-2" />,
    },
    {
      id: "legal_notice" as IssueType,
      title: "Legal Notice",
      description: "Draft a formal notice for recovery of dues, breach of contract, or other grievances.",
      icon: <FileText className="w-10 h-10 text-blue-500 mb-2" />,
    },
    {
      id: "rental_agreement" as IssueType,
      title: "Rental Agreement",
      description: "Draft a residential rental agreement between a landlord and tenant.",
      icon: <Home className="w-10 h-10 text-green-500 mb-2" />,
    },
    {
      id: "consumer_complaint" as IssueType,
      title: "Consumer Complaint",
      description: "File a complaint against a seller or service provider for defects or deficiency.",
      icon: <AlertCircle className="w-10 h-10 text-amber-500 mb-2" />,
    },
    {
      id: "cheque_bounce" as IssueType,
      title: "Cheque Bounce Notice",
      description: "Draft a Section 138 notice for dishonored cheques (must be sent within 30 days).",
      icon: <Banknote className="w-10 h-10 text-red-500 mb-2" />,
    },
    {
      id: "rti_application" as IssueType,
      title: "RTI Application",
      description: "File a Right to Information application to get info from public authorities.",
      icon: <FileSearch className="w-10 h-10 text-purple-500 mb-2" />,
    },
    
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-full p-6 animate-fade-in">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold mb-2">How can I help you today?</h1>
        <p className="text-muted-foreground">Select the type of legal document you need assistance with.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 max-w-7xl w-full">
        {issues.map((issue) => (
          <Card 
            key={issue.id}
            className="cursor-pointer hover:shadow-lg transition-all hover:scale-105 border-2 hover:border-primary flex flex-col items-center text-center h-full"
            onClick={() => onSelect(issue.id)}
          >
            <CardHeader className="flex flex-col items-center pb-2">
              {issue.icon}
              <CardTitle className="text-lg">{issue.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>{issue.description}</CardDescription>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};
