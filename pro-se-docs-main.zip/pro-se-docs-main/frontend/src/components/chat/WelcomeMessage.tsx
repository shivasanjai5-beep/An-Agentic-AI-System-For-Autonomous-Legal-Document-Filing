import { Bot } from "lucide-react";
import { QuickResponses } from "./QuickResponses";

const quickResponses = [
  "Draft Legal Notice",
  "Rental Agreement",
  "Consumer Complaint",
  "RTI Application",
];

interface WelcomeMessageProps {
  onQuickResponse: (response: string) => void;
}

export const WelcomeMessage = ({ onQuickResponse }: WelcomeMessageProps) => {
  return (
    <div className="flex gap-3 mb-4 animate-fade-in-up">
      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
        <Bot className="w-5 h-5 text-primary" />
      </div>
      <div className="max-w-[80%] bg-card border rounded-2xl px-4 py-3 shadow-soft">
        <p className="text-base leading-relaxed mb-2">
          Hi! I'm your AI legal assistant. 👋
        </p>
        <p className="text-base leading-relaxed mb-2">
          I can help you draft formal Indian legal documents like Legal Notices, Rental Agreements, and more. 
        </p>
        <p className="text-base leading-relaxed font-medium mb-2">
          What would you like to draft today?
        </p>
        <QuickResponses responses={quickResponses} onSelect={onQuickResponse} />
      </div>
    </div>
  );
};
