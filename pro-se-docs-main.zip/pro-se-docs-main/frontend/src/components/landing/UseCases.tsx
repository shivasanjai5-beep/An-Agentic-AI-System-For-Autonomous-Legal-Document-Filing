import { Scale, Home, ShoppingCart, Heart, Car } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const useCases = [
  {
    icon: Scale,
    title: "Small Claims Court",
    description: "File claims up to ₹20,000 in district courts",
    available: true,
  },
  {
    icon: Home,
    title: "Landlord-Tenant Disputes",
    description: "Resolve rent, deposit, and maintenance issues",
    available: true,
  },
  {
    icon: ShoppingCart,
    title: "Consumer Complaints",
    description: "File complaints for defective goods or poor services",
    available: true,
  },
  {
    icon: Car,
    title: "Traffic Court Appeals",
    description: "Challenge unfair traffic violations and fines",
    available: false,
  },
];

export const UseCases = () => {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">
            What Can You{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              File?
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            We support a wide range of legal documents for Indian courts
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {useCases.map((useCase, index) => (
            <Card
              key={useCase.title}
              className={`p-6 transition-all duration-300 animate-fade-in relative overflow-hidden ${
                useCase.available
                  ? "hover:shadow-medium hover:-translate-y-1 cursor-pointer border-2"
                  : "opacity-60"
              }`}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              {!useCase.available && (
                <Badge className="absolute top-4 right-4 bg-accent">
                  Coming Soon
                </Badge>
              )}
              <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                <useCase.icon className="w-7 h-7 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">{useCase.title}</h3>
              <p className="text-muted-foreground">{useCase.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
