import { ArrowRight } from "lucide-react";
import stepChatImage from "@/assets/step-chat.jpg";
import stepGenerateImage from "@/assets/step-generate.jpg";
import stepFileImage from "@/assets/step-file.jpg";

const steps = [
  {
    number: "01",
    title: "Tell Your Story in your language",
    description: "Chat with our AI to describe your legal issue in plain English/ தமிழ்/ हिन्दी/ తెలుగు/ മലയാളം/ ಕನ್ನಡ",
    image: stepChatImage,
  },
  {
    number: "02",
    title: "AI Creates Documents",
    description: "Our AI generates court-ready documents tailored to your case",
    image: stepGenerateImage,
  },
  {
    number: "03",
    title: "File with Confidence",
    description: "Download your documents with step-by-step filing instructions",
    image: stepFileImage,
  },
];

export const HowItWorks = () => {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">
            Simple as{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              1-2-3
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Get your legal documents ready in three easy steps
          </p>
        </div>

        <div className="space-y-20">
          {steps.map((step, index) => (
            <div
              key={step.number}
              className={`flex flex-col ${
                index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"
              } gap-12 items-center animate-fade-in`}
            >
              <div className="flex-1 space-y-6">
                <div className="inline-block">
                  <div className="text-6xl font-bold bg-gradient-primary bg-clip-text text-transparent">
                    {step.number}
                  </div>
                </div>
                <h3 className="text-3xl md:text-4xl font-bold">{step.title}</h3>
                <p className="text-xl text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>

              <div className="flex-1">
                <div className="relative group">
                  <div className="absolute inset-0 bg-gradient-primary opacity-20 blur-2xl rounded-2xl group-hover:opacity-30 transition-opacity"></div>
                  <img
                    src={step.image}
                    alt={step.title}
                    className="relative rounded-2xl shadow-large w-full"
                  />
                </div>
              </div>

              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute left-1/2 transform -translate-x-1/2">
                  <ArrowRight className="w-8 h-8 text-primary rotate-90" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
