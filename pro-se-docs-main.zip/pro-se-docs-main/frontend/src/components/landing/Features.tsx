import { MessageSquare, FileText, CheckCircle, MapPin, BookOpen, Lock } from "lucide-react";
import { Card } from "@/components/ui/card";

const features = [
  {
    icon: MessageSquare,
    title: "Smart Intake Assistant",
    description: "Understands your situation and asks relevant questions in simple language",
  },
  {
    icon: FileText,
    title: "Document Generation",
    description: "Creates legally-sound documents using proven templates from Indian courts",
  },
  {
    icon: CheckCircle,
    title: "Quality Validation",
    description: "AI reviews for errors, inconsistencies, and completeness",
  },
  {
    icon: MapPin,
    title: "Jurisdiction-Aware",
    description: "Follows rules specific to your state and district court",
  },
  {
    icon: BookOpen,
    title: "Plain English",
    description: "Explains legal terms in language you understand",
  },
  {
    icon: Lock,
    title: "Secure & Private",
    description: "Your information is encrypted and never shared",
  },
];

export const Features = () => {
  return (
    <section className="py-20 bg-gradient-hero">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">
            Powered by{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Advanced AI Agents
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Three collaborative AI agents work together to ensure accuracy
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card
              key={feature.title}
              className="p-6 hover:shadow-medium transition-all duration-300 hover:-translate-y-1 group animate-fade-in border-2"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-all">
                <feature.icon className="w-7 h-7 text-primary group-hover:text-primary-foreground transition-colors" />
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
