import { HeroButton } from "@/components/ui/button-variants";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export const FinalCTA = () => {
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-primary opacity-10"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(20,184,166,0.2),transparent_70%)]"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <h2 className="text-4xl md:text-5xl font-bold">
            Ready to Get{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Started?
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-muted-foreground">
            File your legal documents in under 30 minutes
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/chat">
              <HeroButton>
                Start Filing for Free <ArrowRight className="ml-2 h-5 w-5" />
              </HeroButton>
            </Link>
          </div>
          <p className="text-sm text-muted-foreground">
            No signup required for demo • Try it now
          </p>
        </div>
      </div>
    </section>
  );
};
