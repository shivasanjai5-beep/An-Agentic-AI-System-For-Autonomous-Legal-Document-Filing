import { IndianRupee, Clock, HelpCircle } from "lucide-react";
import { Card } from "@/components/ui/card";

const problems = [
  {
    icon: IndianRupee,
    title: "Expensive",
    description: "Lawyers charge ₹500-5000+ for simple document preparation",
  },
  {
    icon: Clock,
    title: "Time-Consuming",
    description: "Weeks of back-and-forth consultations and revisions",
  },
  {
    icon: HelpCircle,
    title: "Confusing",
    description: "Legal jargon and complex procedures are overwhelming",
  },
];

export const ProblemStatement = () => {
  return (
    <section className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">
            Legal Help Shouldn't Cost{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">
              Thousands
            </span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {problems.map((problem, index) => (
            <Card
              key={problem.title}
              className="p-8 hover:shadow-medium transition-all duration-300 hover:-translate-y-2 animate-fade-in-up border-2"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mb-6">
                <problem.icon className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-2xl font-bold mb-3">{problem.title}</h3>
              <p className="text-muted-foreground text-lg">{problem.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
