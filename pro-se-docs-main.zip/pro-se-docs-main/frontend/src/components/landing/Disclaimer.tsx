import { AlertCircle } from "lucide-react";

export const Disclaimer = () => {
  return (
    <section className="py-16 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto flex gap-6 items-start">
          <div className="flex-shrink-0">
            <AlertCircle className="w-8 h-8 text-accent" />
          </div>
          <div className="space-y-3">
            <h3 className="text-2xl font-bold">Important Information</h3>
            <p className="text-muted-foreground leading-relaxed">
              LegalDocs AI is a document preparation tool, not a lawyer or law firm. It does not
              provide legal advice. For complex cases, please consult a licensed advocate. This is
              an educational project demonstrating AI capabilities in the Indian legal context.
            </p>
            <a
              href="#"
              className="text-primary hover:underline font-medium inline-block"
            >
              Read Full Terms & Conditions →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
