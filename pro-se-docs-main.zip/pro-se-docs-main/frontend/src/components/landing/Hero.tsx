import { HeroButton, SecondaryButton } from "@/components/ui/button-variants";
import { ArrowRight, Play } from "lucide-react";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-legal.jpg";

export const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-hero">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(20,184,166,0.1),transparent_50%),radial-gradient(circle_at_70%_50%,rgba(168,85,247,0.1),transparent_50%)]"></div>
      
      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in-up">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight">
                File Legal Documents in{" "}
                <span className="bg-gradient-primary bg-clip-text text-transparent">
                  Minutes
                </span>
                , Not Days
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground">
                AI-powered legal document assistant for small claims, consumer complaints, and more.{" "}
                <span className="font-semibold text-foreground">No lawyer needed.</span>
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/chat">
                <HeroButton>
                  Start Filing Now <ArrowRight className="ml-2 h-5 w-5" />
                </HeroButton>
              </Link>
              <SecondaryButton>
                <Play className="mr-2 h-4 w-4" /> Watch Demo
              </SecondaryButton>
            </div>

            <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2 bg-card px-4 py-2 rounded-full shadow-soft">
                ✓ No Credit Card Required
              </div>
              <div className="flex items-center gap-2 bg-card px-4 py-2 rounded-full shadow-soft">
                ✓ 100% Free for Students
              </div>
            </div>
          </div>

          <div className="relative animate-float">
            <div className="absolute inset-0 bg-gradient-primary opacity-20 blur-3xl rounded-full"></div>
            <img
              src={heroImage}
              alt="AI Legal Assistant"
              className="relative rounded-2xl shadow-large w-full"
            />
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-primary rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-3 bg-primary rounded-full"></div>
        </div>
      </div>
    </section>
  );
};
