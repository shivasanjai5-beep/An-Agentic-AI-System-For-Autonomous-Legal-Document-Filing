import { Hero } from "@/components/landing/Hero";
import { ProblemStatement } from "@/components/landing/ProblemStatement";
import { HowItWorks } from "@/components/landing/HowItWorks";
import { Features } from "@/components/landing/Features";
import { UseCases } from "@/components/landing/UseCases";
import { Disclaimer } from "@/components/landing/Disclaimer";
import { FinalCTA } from "@/components/landing/FinalCTA";
import { Footer } from "@/components/landing/Footer";

const Landing = () => {
  return (
    <div className="min-h-screen">
      <Hero />
      <ProblemStatement />
      <HowItWorks />
      <Features />
      <UseCases />
      <Disclaimer />
      <FinalCTA />
      <Footer />
    </div>
  );
};

export default Landing;
