import { useState, useRef, useEffect } from "react";
import { ChatHeader } from "@/components/chat/ChatHeader";
import { ChatMessage } from "@/components/chat/ChatMessage";
import { ChatInput } from "@/components/chat/ChatInput";
import { WelcomeMessage } from "@/components/chat/WelcomeMessage";
import { TypingIndicator } from "@/components/chat/TypingIndicator";
import { IssueSelector, IssueType } from "@/components/chat/IssueSelector";
import { geminiService } from "@/services/geminiService";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { useSpeech } from "@/hooks/useSpeech";

interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: string;
  generatedHtml?: string;
}

const Chat = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [issueType, setIssueType] = useState<IssueType | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { speak, stopSpeaking, isSpeaking } = useSpeech();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Clean up session and speech on unmount or return to landing
  useEffect(() => {
    return () => {
      stopSpeaking();
    };
  }, [stopSpeaking]);

  // Sync speaking state
  useEffect(() => {
    if (!isSpeaking) {
      setSpeakingMessageId(null);
    }
  }, [isSpeaking]);

  const stripMarkdown = (text: string) => {
    return text
      .replace(/[#*_`]/g, "") // Remove simple markers
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1") // Links
      .replace(/\n+/g, ". "); // Newlines to pauses
  };

  const handleSpeak = (content: string, id: string) => {
    if (speakingMessageId === id) {
      stopSpeaking();
      setSpeakingMessageId(null);
    } else {
      stopSpeaking();
      const cleanText = stripMarkdown(content);
      speak(cleanText);
      setSpeakingMessageId(id);
    }
  };

  const handleIssueSelect = async (selectedIssue: IssueType) => {
    setIssueType(selectedIssue);
    geminiService.setIssueType(selectedIssue);
    
    // Clear previous session if any when starting fresh
    await geminiService.clearSession();
    
    setMessages([]); // Reset messages
    stopSpeaking();
    
    // Optionally trigger an initial greeting from the AI based on the selection
    // Or just show the WelcomeMessage (which we might want to skip or customize)
  };

  const handleDownload = async (html: string, format: "pdf" | "docx") => {
    try {
      toast.info(`Generating ${format.toUpperCase()}...`);
      await geminiService.downloadDocument(html, format);
      toast.success("Download started!");
    } catch (error) {
      console.error("Download error:", error);
      toast.error(`Failed to download ${format.toUpperCase()}.`);
    }
  };

  const handleSendMessage = async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content,
      timestamp: new Date().toLocaleTimeString("en-IN", {
        hour: "2-digit",
        minute: "2-digit",
      }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsTyping(true);

    try {
      // Get AI response from Backend
      const response = await geminiService.sendMessage(content);

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response.response,
        timestamp: new Date().toLocaleTimeString("en-IN", {
          hour: "2-digit",
          minute: "2-digit",
        }),
        generatedHtml: response.generated_html
      };

      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error("Error getting AI response:", error);
      
      // Show error message to user
      toast.error("Failed to get response from AI. Please check your connection and try again.");
      
      // Add error message to chat
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "system",
        content: "Failed to get AI response. Please try again.",
        timestamp: new Date().toLocaleTimeString("en-IN", {
          hour: "2-digit",
          minute: "2-digit",
        }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleBackToSelection = () => {
    setIssueType(null);
    geminiService.clearSession();
    setMessages([]);
    stopSpeaking();
  };

  return (
    <div className="flex flex-col h-screen">
      <ChatHeader onBack={issueType ? handleBackToSelection : undefined} />

      <main className="flex-1 overflow-y-auto relative">
        {!issueType ? (
          <IssueSelector onSelect={handleIssueSelect} />
        ) : (
          <>
            <div className="container mx-auto px-4 py-6 max-w-4xl">
              {messages.length === 0 ? (
                <WelcomeMessage onQuickResponse={handleSendMessage} />
              ) : (
                <>
                  {messages.map((message) => (
                    <ChatMessage
                      key={message.id}
                      role={message.role}
                      content={message.content}
                      timestamp={message.timestamp}
                      generatedHtml={message.generatedHtml}
                      onDownload={handleDownload}
                      onSpeak={() => handleSpeak(message.content, message.id)}
                      onStop={() => {
                        stopSpeaking();
                        setSpeakingMessageId(null);
                      }}
                      isSpeaking={speakingMessageId === message.id}
                    />
                  ))}
                  {isTyping && <TypingIndicator />}
                </>
              )}
              <div ref={messagesEndRef} />
            </div>
          </>
        )}
      </main>

      {issueType && (
        <ChatInput onSend={handleSendMessage} disabled={isTyping} />
      )}
    </div>
  );
};

export default Chat;
