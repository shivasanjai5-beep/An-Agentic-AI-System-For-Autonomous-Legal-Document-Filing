import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, Shield, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";

const Landing = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex flex-col font-sans">
      {/* Simple Navbar */}
      <nav className="bg-white/80 backdrop-blur-md shadow-sm border-b border-indigo-100 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-br from-blue-600 to-indigo-600 p-1.5 rounded-lg shadow-sm">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-indigo-700">
              LegalDocs AI
            </span>
          </div>
          <div className="text-sm text-indigo-600/80 hidden sm:block font-medium bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
            Project By: Department of IT, SREC, Coimbatore
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          
          {/* Hero Section */}
          <div className="text-center mb-16 space-y-6">
            <div className="inline-block animate-bounce-slow">
              <span className="bg-gradient-to-r from-orange-100 to-amber-100 text-orange-700 text-xs font-bold px-3 py-1 rounded-full border border-orange-200 shadow-sm">
                BETA VERSION
              </span>
            </div>
            <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 tracking-tight leading-tight">
              Legal Document Assistant
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
              Draft formal Indian legal documents in minutes using AI. <br className="hidden md:block"/>
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent font-bold">Free tool for students and citizens.</span>
            </p>
            <div className="pt-4">
              <Link to="/chat">
                <Button className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:via-indigo-700 hover:to-purple-700 text-white text-lg px-8 py-6 h-auto shadow-xl shadow-indigo-500/20 transition-all hover:scale-105 rounded-full">
                  Start Drafting Free
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>

          {/* Feature Grid - 'Student Project' Style Cards */}
          <div className="grid md:grid-cols-2 gap-6 mb-16">
            <div className="bg-white/60 backdrop-blur-sm p-6 rounded-2xl shadow-sm border border-white/50 hover:shadow-lg transition-all hover:border-blue-200 group hover:-translate-y-1">
              <div className="h-12 w-12 bg-blue-50 rounded-xl flex items-center justify-center mb-4 group-hover:bg-blue-100 transition-colors shadow-inner">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-blue-700 transition-colors">Supported Documents</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full shadow-sm"></span>
                  Legal Notices (Sec 138, Recovery)
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full shadow-sm"></span>
                  Rental Agreements
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full shadow-sm"></span>
                  Consumer Complaints
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-blue-400 rounded-full shadow-sm"></span>
                  RTI Applications
                </li>
              </ul>
            </div>

            <div className="bg-white/60 backdrop-blur-sm p-6 rounded-2xl shadow-sm border border-white/50 hover:shadow-lg transition-all hover:border-green-200 group hover:-translate-y-1">
              <div className="h-12 w-12 bg-green-50 rounded-xl flex items-center justify-center mb-4 group-hover:bg-green-100 transition-colors shadow-inner">
                <BookOpen className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-green-700 transition-colors">How It Works</h3>
              <div className="space-y-4 text-gray-600">
                <div className="flex gap-4 items-start">
                  <span className="flex-shrink-0 w-6 h-6 bg-gradient-to-br from-green-100 to-emerald-100 text-green-700 rounded-full flex items-center justify-center text-sm font-bold mt-0.5 shadow-sm border border-green-200">1</span>
                  <p>Describe your issue in the chat box.</p>
                </div>
                <div className="flex gap-4 items-start">
                  <span className="flex-shrink-0 w-6 h-6 bg-gradient-to-br from-green-100 to-emerald-100 text-green-700 rounded-full flex items-center justify-center text-sm font-bold mt-0.5 shadow-sm border border-green-200">2</span>
                  <p>Answer a few simple questions from the AI.</p>
                </div>
                <div className="flex gap-4 items-start">
                  <span className="flex-shrink-0 w-6 h-6 bg-gradient-to-br from-green-100 to-emerald-100 text-green-700 rounded-full flex items-center justify-center text-sm font-bold mt-0.5 shadow-sm border border-green-200">3</span>
                  <p>Download your formatted Word document.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Simple Disclaimer */}
          <div className="bg-gradient-to-r from-orange-50 via-amber-50 to-yellow-50 border border-orange-100/50 rounded-2xl p-6 text-center shadow-sm backdrop-blur-sm">
            <p className="text-sm text-orange-800 leading-relaxed font-medium">
              <strong>⚠️ Disclaimer:</strong> This is a college project prototype. The documents are generated by AI and should be verified by a legal professional before use. We do not take responsibility for the legal validity of the content.
            </p>
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white/50 backdrop-blur-sm border-t border-indigo-100 mt-auto py-8">
        <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
          <p className="mb-2 font-medium text-gray-600">© {new Date().getFullYear()} LegalDocs AI • Built for Indian Legal System</p>
          <p className="text-xs text-indigo-400">Made with ❤️ by the Department of IT, SREC, Coimbatore</p>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
