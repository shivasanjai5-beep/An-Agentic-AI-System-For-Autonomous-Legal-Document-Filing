import { useState, useCallback, useRef, useEffect } from 'react';

interface SpeechState {
  isSpeaking: boolean;
  isListening: boolean;
  isProcessing: boolean;
  transcript: string;
  interimTranscript: string;
  error: string | null;
  supported: boolean;
}

export const useSpeech = () => {
  const [state, setState] = useState<SpeechState>({
    isSpeaking: false,
    isListening: false,
    isProcessing: false,
    transcript: '',
    interimTranscript: '',
    error: null,
    supported: false,
  });

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  // Initialize Audio
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const audio = new Audio();
      audioRef.current = audio;
      
      // Check for MediaRecorder support
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        setState(prev => ({ ...prev, supported: true }));
      } else {
        setState(prev => ({ ...prev, supported: false, error: 'Microphone not supported in this browser' }));
      }

      // Cleanup audio on unmount
      return () => {
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current = null;
        }
      };
    }
  }, []);

  // TTS: Speak text using Backend (Edge-TTS)
  const speak = useCallback(async (text: string) => {
    if (!audioRef.current) return;

    try {
      // Stop any current audio
      audioRef.current.pause();
      
      setState(prev => ({ ...prev, isSpeaking: true, error: null }));

      // Fetch audio from backend
      const response = await fetch('http://localhost:8000/tts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate speech');
      }

      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);

      audioRef.current.src = audioUrl;
      audioRef.current.onended = () => {
        setState(prev => ({ ...prev, isSpeaking: false }));
        URL.revokeObjectURL(audioUrl); // Cleanup
      };
      
      audioRef.current.onerror = () => {
        setState(prev => ({ ...prev, isSpeaking: false, error: "Error playing audio" }));
      };

      await audioRef.current.play();

    } catch (err: any) {
      console.error('TTS Error:', err);
      setState(prev => ({ ...prev, isSpeaking: false, error: err.message || "Failed to speak text" }));
    }
  }, []);

  // TTS: Stop speaking
  const stopSpeaking = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setState(prev => ({ ...prev, isSpeaking: false }));
    }
  }, []);

  // STT: Start listening using MediaRecorder
  const startListening = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        // Stop all tracks to release microphone
        stream.getTracks().forEach(track => track.stop());
        
        // Process audio
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
        await processAudio(audioBlob);
      };

      mediaRecorder.start();
      setState(prev => ({ ...prev, isListening: true, error: null }));

    } catch (err: any) {
      console.error('Microphone Error:', err);
      setState(prev => ({ 
        ...prev, 
        isListening: false, 
        error: "Microphone access denied or not available." 
      }));
    }
  }, []);

  // STT: Stop listening and process
  const stopListening = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      setState(prev => ({ ...prev, isListening: false, isProcessing: true }));
    }
  }, []);

  // Process audio (Send to backend Whisper)
  const processAudio = async (audioBlob: Blob) => {
    try {
      const formData = new FormData();
      // Ensure filename has extension for backend detection
      formData.append('file', audioBlob, 'recording.webm');

      const response = await fetch('http://localhost:8000/stt', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Transcription failed');
      }

      const data = await response.json();
      
      setState(prev => ({
        ...prev,
        isProcessing: false,
        transcript: prev.transcript + (prev.transcript ? ' ' : '') + data.text,
      }));

    } catch (err: any) {
      console.error('STT Processing Error:', err);
      setState(prev => ({ 
        ...prev, 
        isProcessing: false, 
        error: "Failed to transcribe audio. Please try again." 
      }));
    }
  };

  // STT: Reset transcript
  const resetTranscript = useCallback(() => {
    setState(prev => ({ ...prev, transcript: '', interimTranscript: '' }));
  }, []);

  return {
    ...state,
    speak,
    stopSpeaking,
    startListening,
    stopListening,
    resetTranscript
  };
};
