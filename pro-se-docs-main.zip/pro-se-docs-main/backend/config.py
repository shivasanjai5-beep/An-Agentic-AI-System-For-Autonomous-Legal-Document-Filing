"""
Application configuration using Pydantic Settings.
Centralized management of all environment variables.
"""

from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.
    
    Environment variables are automatically loaded from:
    - .env file (if present)
    - System environment variables (takes precedence)
    """
    
    # Required: OpenRouter API Configuration
    OPENROUTER_API_KEY: str

    # Optional: Tavily API Key for Web Search
    TAVILY_API_KEY: str = ""
    
    # Optional: LLM Model Configuration
    OPENROUTER_MODEL: str = "xiaomi/mimo-v2-flash:free"
    OPENROUTER_TEMPERATURE: float = 0.3
    
    # Optional: OpenRouter Ranking Headers
    SITE_URL: str = ""
    SITE_NAME: str = "Legal Document Assistant"
    
    # Optional: CORS Configuration
    CORS_ORIGINS: str = "*"  # Comma-separated list or "*" for all
    
    # Optional: Server Configuration
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # Optional: Application Metadata
    APP_VERSION: str = "2.0.0"
    APP_TITLE: str = "Legal Document Assistant"
    APP_DESCRIPTION: str = "AI-powered legal document drafting assistant using LangGraph and OpenRouter"
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",  # Ignore extra environment variables
    )
    
    def get_cors_origins(self) -> List[str]:
        """
        Parse CORS_ORIGINS string into a list.
        
        Returns:
            List of allowed origins, or ["*"] if CORS_ORIGINS is "*"
        """
        if self.CORS_ORIGINS.strip() == "*":
            return ["*"]
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]


# Create a singleton settings instance
settings = Settings()

