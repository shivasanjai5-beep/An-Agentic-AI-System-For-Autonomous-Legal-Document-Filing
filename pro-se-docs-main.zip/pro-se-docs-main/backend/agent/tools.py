"""
LangChain tools for the Legal Document Assistant.
"""

from typing import Dict, Any, List
from langchain_core.tools import tool
from langchain_community.tools.tavily_search import TavilySearchResults
from jinja2 import Template

# Import templates
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import settings
from templates.legal_notice import LEGAL_NOTICE_HTML, REQUIRED_FIELDS as LEGAL_NOTICE_FIELDS
from templates.rental_agreement import RENTAL_AGREEMENT_HTML, REQUIRED_FIELDS as RENTAL_FIELDS
from templates.consumer_complaint import CONSUMER_COMPLAINT_HTML, REQUIRED_FIELDS as CONSUMER_FIELDS
from templates.cheque_bounce import CHEQUE_BOUNCE_HTML, REQUIRED_FIELDS as CHEQUE_FIELDS
from templates.rti_application import RTI_APPLICATION_HTML, REQUIRED_FIELDS as RTI_FIELDS


@tool
def search_legal_info(query: str) -> str:
    """
    Search the web for legal information related to the query.
    Returns search results with citations/source URLs.
    Use this for answering general legal questions.
    """
    if not settings.TAVILY_API_KEY:
        return "Web search is disabled. No Tavily API key found."
    
    try:
        # Initialize the tool
        search = TavilySearchResults(
            max_results=5,
            include_answer=True,
            include_raw_content=False,
            tavily_api_key=settings.TAVILY_API_KEY
        )
        
        # Add context to the query
        enhanced_query = f"{query} Indian law"
        
        # Execute search
        results = search.invoke(enhanced_query)
        
        # Format results
        formatted_results = "Search Results:\n\n"
        # Tavily results are usually a list of dicts
        if isinstance(results, list):
            for i, res in enumerate(results, 1):
                formatted_results += f"{i}. {res.get('content', '')}\n   Source: {res.get('url', '')}\n\n"
        else:
            formatted_results += str(results)
            
        formatted_results += "\nINSTRUCTIONS: You must cite these sources in your answer using [1], [2] format and list them at the end under a 'Sources' section."
        
        return formatted_results
    except Exception as e:
        return f"Error performing web search: {str(e)}"


@tool
def get_legal_notice_template() -> Dict[str, Any]:
    """
    Returns the required fields and structure for a Legal Notice.
    Use this tool when the user confirms they want to generate a Legal Notice.
    This will tell you what information you need to collect from the user.
    
    Returns:
        A dictionary containing:
        - document_type: The type of document (Legal Notice)
        - required_fields: Dictionary of field names and their descriptions
        - description: A description of what a legal notice is
    """
    return {
        "document_type": "Legal Notice",
        "required_fields": LEGAL_NOTICE_FIELDS,
        "description": (
            "A formal legal communication sent to a person or entity, "
            "informing them of your grievance and your intention to undertake "
            "legal proceedings against them."
        )
    }


@tool
def generate_legal_notice(
    sender_name: str,
    sender_address: str,
    recipient_name: str,
    recipient_address: str,
    subject_matter: str,
    notice_content: str,
    demand_action: str,
    notice_period: str,
    date: str,
    advocate_name: str,
) -> str:
    """
    Generates the HTML content for a Legal Notice using the provided data.
    Use this tool only after you have collected ALL required information from the user.
    
    Args:
        sender_name: Name of the person sending the notice
        sender_address: Full address of the sender
        recipient_name: Name of the person receiving the notice
        recipient_address: Full address of the recipient
        subject_matter: Brief subject of the legal notice (e.g., "Recovery of Dues", "Breach of Contract")
        notice_content: Detailed content/body of the notice explaining the grievance
        demand_action: Specific action demanded from the recipient (e.g., "pay the outstanding amount of Rs. 50,000")
        notice_period: Time period given to comply (e.g., "15", "30") - just the number of days
        date: Date of the notice (e.g., "24th December, 2024")
        advocate_name: Name of the advocate (or "Self" if sending personally)
    
    Returns:
        The generated HTML content for the legal notice document
    """
    try:
        template = Template(LEGAL_NOTICE_HTML)
        
        data = {
            "sender_name": sender_name,
            "sender_address": sender_address,
            "recipient_name": recipient_name,
            "recipient_address": recipient_address,
            "subject_matter": subject_matter,
            "notice_content": notice_content,
            "demand_action": demand_action,
            "notice_period": notice_period,
            "date": date,
            "advocate_name": advocate_name,
        }
        
        return template.render(**data)
    except Exception as e:
        return f"Error generating document: {str(e)}"


@tool
def get_rental_agreement_template() -> Dict[str, Any]:
    """
    Returns the required fields for a Rental Agreement.
    Use this tool when the user selects Rental Agreement.
    
    Returns:
        A dictionary containing document type, required fields, and description.
    """
    return {
        "document_type": "Rental Agreement",
        "required_fields": RENTAL_FIELDS,
        "description": "A contract between a landlord and a tenant that outlines the terms of renting a residential property."
    }


@tool
def generate_rental_agreement(
    landlord_name: str,
    landlord_father: str,
    landlord_address: str,
    tenant_name: str,
    tenant_father: str,
    tenant_address: str,
    property_address: str,
    lease_start_date: str,
    lease_duration: str,
    monthly_rent: str,
    security_deposit: str,
    notice_period: str,
    agreement_date: str,
    place: str,
) -> str:
    """
    Generates the HTML content for a Rental Agreement.
    Use this tool only after you have collected ALL required information.
    
    Args:
        landlord_name: Landlord's full name
        landlord_father: Landlord's father's name
        landlord_address: Landlord's address
        tenant_name: Tenant's full name
        tenant_father: Tenant's father's name
        tenant_address: Tenant's permanent address
        property_address: Address of rented property
        lease_start_date: Start date of lease
        lease_duration: Duration in months
        monthly_rent: Monthly rent amount
        security_deposit: Security deposit amount
        notice_period: Notice period for termination
        agreement_date: Date of signing
        place: Place of agreement
    
    Returns:
        Generated HTML content
    """
    try:
        template = Template(RENTAL_AGREEMENT_HTML)
        data = locals()
        return template.render(**data)
    except Exception as e:
        return f"Error generating document: {str(e)}"


@tool
def get_consumer_complaint_template() -> Dict[str, Any]:
    """
    Returns the required fields for a Consumer Complaint.
    Use this tool when the user selects Consumer Complaint.
    """
    return {
        "document_type": "Consumer Complaint",
        "required_fields": CONSUMER_FIELDS,
        "description": "A complaint filed in the Consumer Disputes Redressal Commission against a seller or service provider."
    }


@tool
def generate_consumer_complaint(
    district_name: str,
    current_year: str,
    complainant_name: str,
    complainant_parent_name: str,
    complainant_address: str,
    opposite_party_name: str,
    opposite_party_address: str,
    product_service_name: str,
    invoice_number: str,
    purchase_date: str,
    amount_paid: str,
    complaint_details: str,
    defect_deficiency_type: str,
    relief_sought: str,
    place: str,
    date: str,
) -> str:
    """
    Generates the HTML content for a Consumer Complaint.
    Use this tool only after you have collected ALL required information.
    """
    try:
        template = Template(CONSUMER_COMPLAINT_HTML)
        data = locals()
        return template.render(**data)
    except Exception as e:
        return f"Error generating document: {str(e)}"


@tool
def get_cheque_bounce_template() -> Dict[str, Any]:
    """
    Returns the required fields for a Cheque Bounce Notice (Section 138).
    Use this tool when the user selects Cheque Bounce Notice.
    """
    return {
        "document_type": "Cheque Bounce Notice (Section 138)",
        "required_fields": CHEQUE_FIELDS,
        "description": "A legal notice sent to a person who has issued a cheque that was returned unpaid (bounced) by the bank."
    }


@tool
def generate_cheque_bounce(
    payee_name: str,
    payee_address: str,
    advocate_name: str,
    advocate_address: str,
    drawer_name: str,
    drawer_address: str,
    cheque_number: str,
    cheque_date: str,
    amount: str,
    bank_name: str,
    transaction_details: str,
    return_reason: str,
    return_date: str,
    date: str,
) -> str:
    """
    Generates the HTML content for a Cheque Bounce Notice.
    Use this tool only after you have collected ALL required information.
    """
    try:
        template = Template(CHEQUE_BOUNCE_HTML)
        data = locals()
        return template.render(**data)
    except Exception as e:
        return f"Error generating document: {str(e)}"


@tool
def get_rti_application_template() -> Dict[str, Any]:
    """
    Returns the required fields for an RTI Application.
    Use this tool when the user selects RTI Application.
    """
    return {
        "document_type": "RTI Application",
        "required_fields": RTI_FIELDS,
        "description": "An application to request information from a Public Authority under the Right to Information Act, 2005."
    }


@tool
def generate_rti_application(
    department_name: str,
    department_address: str,
    applicant_name: str,
    applicant_address: str,
    applicant_phone: str,
    applicant_email: str,
    subject_matter: str,
    period_of_info: str,
    information_sought: str,
    preferred_format: str,
    bpl_status: str,
    fee_amount: str,
    payment_mode: str,
    payment_details: str,
    payment_date: str,
    place: str,
    date: str,
) -> str:
    """
    Generates the HTML content for an RTI Application.
    Use this tool only after you have collected ALL required information.
    """
    try:
        template = Template(RTI_APPLICATION_HTML)
        data = locals()
        return template.render(**data)
    except Exception as e:
        return f"Error generating document: {str(e)}"


def get_tools() -> List:
    """
    Returns all available tools for the legal agent.
    
    Returns:
        List of LangChain tools
    """
    return [
        search_legal_info,
        get_legal_notice_template, generate_legal_notice,
        get_rental_agreement_template, generate_rental_agreement,
        get_consumer_complaint_template, generate_consumer_complaint,
        get_cheque_bounce_template, generate_cheque_bounce,
        get_rti_application_template, generate_rti_application
    ]
