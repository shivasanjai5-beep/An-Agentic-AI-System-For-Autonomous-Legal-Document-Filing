"""
LLM configuration using OpenRouter (via ChatOpenAI).
"""

from langchain_openai import ChatOpenAI

# Import config - use relative import since we're in a subdirectory
import sys
from pathlib import Path
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))
from config import settings


def get_llm(
    model: str = None,
    temperature: float = None,
) -> ChatOpenAI:
    """
    Creates and returns a ChatOpenAI instance configured for OpenRouter.
    
    Args:
        model: The model to use (defaults to OPENROUTER_MODEL from config)
        temperature: Sampling temperature for response generation (defaults to OPENROUTER_TEMPERATURE from config)
        
    Returns:
        Configured ChatOpenAI instance
    """
    # Use config defaults if not provided
    if model is None:
        model = settings.OPENROUTER_MODEL
    if temperature is None:
        temperature = settings.OPENROUTER_TEMPERATURE
        
    default_headers = {}
    if settings.SITE_URL:
        default_headers["HTTP-Referer"] = settings.SITE_URL
    if settings.SITE_NAME:
        default_headers["X-Title"] = settings.SITE_NAME
    
    return ChatOpenAI(
        model=model,
        temperature=temperature,
        openai_api_key=settings.OPENROUTER_API_KEY,
        openai_api_base="https://openrouter.ai/api/v1",
        default_headers=default_headers,
        max_retries=2,
        request_timeout=60,
    )
