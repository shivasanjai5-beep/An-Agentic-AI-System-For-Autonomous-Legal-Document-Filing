"""
LangChain Agent module for the Legal Document Assistant.
"""

from .llm import get_llm
from .tools import get_legal_notice_template, generate_legal_notice, get_tools
from .memory import SessionMemory, session_memory
from .agent import create_legal_agent, get_agent_executor

__all__ = [
    "get_llm",
    "get_legal_notice_template", 
    "generate_legal_notice",
    "get_tools",
    "SessionMemory",
    "session_memory",
    "create_legal_agent",
    "get_agent_executor",
]

