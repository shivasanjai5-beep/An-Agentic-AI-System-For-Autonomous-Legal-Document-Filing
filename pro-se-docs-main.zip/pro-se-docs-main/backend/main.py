"""
Legal Document Assistant API - FastAPI Backend with LangGraph Agent
"""

from typing import Optional, List
from io import BytesIO
import tempfile
import os
import asyncio

from fastapi import FastAPI, HTTPException, Response, UploadFile, File
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, ToolMessage, BaseMessage

# Configuration
from config import settings

# Document Converters
from htmldocx import HtmlToDocx
from docx import Document

# Voice Services
import edge_tts
from faster_whisper import WhisperModel

# LangGraph Agent
from agent import get_agent_executor, session_memory
from agent.agent import get_system_message

# --- Global Models ---
whisper_model = None

def get_whisper_model():
    """Lazy load Whisper model."""
    global whisper_model
    if whisper_model is None:
        print("Loading Whisper model (base.en)...")
        # Run on CPU with INT8 quantization for speed/compatibility
        whisper_model = WhisperModel("base.en", device="cpu", compute_type="int8")
        print("Whisper model loaded.")
    return whisper_model

# --- App Initialization ---
app = FastAPI(
    title=settings.APP_TITLE,
    description=settings.APP_DESCRIPTION,
    version=settings.APP_VERSION,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.get_cors_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- Pydantic Models ---

class ChatRequest(BaseModel):
    """Request body for the chat endpoint."""
    session_id: str = Field(..., description="Unique session identifier")
    message: str = Field(..., description="User's message")
    issue_type: Optional[str] = Field(None, description="Type of legal issue (e.g., legal_notice, mutual_divorce)")


class ChatResponse(BaseModel):
    """Response body for the chat endpoint."""
    session_id: str
    response: str
    generated_html: Optional[str] = None


class SessionResponse(BaseModel):
    """Response body for session operations."""
    session_id: str
    created: bool = False
    cleared: bool = False


class DocumentRequest(BaseModel):
    """Request body for document download endpoints."""
    html_content: str = Field(..., description="HTML content to convert")


class TTSRequest(BaseModel):
    """Request body for Text-to-Speech."""
    text: str
    voice: str = "en-IN-NeerjaNeural"  # Default to Indian English Female


class STTResponse(BaseModel):
    """Response body for Speech-to-Text."""
    text: str


class HealthResponse(BaseModel):
    """Response body for health check."""
    status: str
    agent: str = "legal_agent"
    version: str = settings.APP_VERSION


# --- Helper Functions ---

def extract_generated_html(messages: List[BaseMessage]) -> Optional[str]:
    """
    Extracts generated HTML content from the agent's message history.
    Checks ToolMessages first (where generation tools return HTML),
    then falls back to AIMessages.
    
    Args:
        messages: List of messages from the agent execution
        
    Returns:
        Extracted HTML string or None if no HTML found
    """
    html_start_markers = ["<!DOCTYPE html>", "<!doctype html>", "<html"]
    html_end_marker = "</html>"
    
    # helper to check string for html
    def find_html(text: str) -> Optional[str]:
        if not text: return None
        text_lower = text.lower()
        for start_marker in html_start_markers:
            start_idx = text_lower.find(start_marker.lower())
            if start_idx != -1:
                end_idx = text_lower.rfind(html_end_marker.lower())
                if end_idx != -1:
                    return text[start_idx:end_idx + len(html_end_marker)]
        return None

    # Iterate in reverse to find the most recent generated document
    for msg in reversed(messages):
        # 1. Check ToolMessages (primary source of generated docs)
        if isinstance(msg, ToolMessage):
            html = find_html(str(msg.content))
            if html:
                return html
        
        # 2. Check AIMessages (fallback if agent outputs HTML directly)
        if isinstance(msg, AIMessage):
            html = find_html(str(msg.content))
            if html:
                return html
                
    return None


# --- Initialize Agent ---
print("Initializing LangGraph Agent...")
try:
    agent = get_agent_executor()
    print("LangGraph Agent initialized successfully")
except Exception as e:
    print(f"ERROR: Failed to initialize agent: {e}")
    raise e


# --- API Endpoints ---

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Chat with the legal document assistant.
    
    Sends a message to the AI agent and returns its response.
    The agent maintains conversation history per session.
    """
    if not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")
    
    try:
        # Get chat history for this session
        chat_history = session_memory.get_history(request.session_id)
        
        # Prepare messages
        messages = list(chat_history)
        messages.append(HumanMessage(content=request.message))
        
        # Run the agent
        result = await agent.ainvoke(
            {
                "messages": messages,
                "issue_type": request.issue_type
            },
            config={"recursion_limit": 10}
        )
        
        # Extract the response from the last AI message
        response_text = ""
        # Get the full list of messages from the result
        result_messages = result["messages"]
        
        for msg in reversed(result_messages):
            if isinstance(msg, AIMessage) and msg.content:
                response_text = msg.content
                break
        
        # Update session memory
        session_memory.add_user_message(request.session_id, request.message)
        session_memory.add_ai_message(request.session_id, response_text)
        
        # Check if response contains generated HTML (scan all messages)
        generated_html = extract_generated_html(result_messages)
        
        return ChatResponse(
            session_id=request.session_id,
            response=response_text,
            generated_html=generated_html,
        )
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Agent error: {str(e)}")


@app.post("/sessions", response_model=SessionResponse)
async def create_session(session_id: str):
    """
    Creates a new chat session.
    
    If the session already exists, returns without error.
    """
    created = session_memory.create_session(session_id)
    return SessionResponse(session_id=session_id, created=created)


@app.delete("/sessions/{session_id}", response_model=SessionResponse)
async def clear_session(session_id: str):
    """
    Clears the chat history for a specific session.
    """
    cleared = session_memory.clear_session(session_id)
    return SessionResponse(session_id=session_id, cleared=cleared)


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Health check endpoint.
    
    Returns the status of the API and agent.
    """
    return HealthResponse(status="healthy")


# --- Document Download Endpoints ---

@app.post("/download/docx")
async def download_docx(request: DocumentRequest):
    """
    Converts HTML content to a DOCX document.
    
    Returns the document as a downloadable file.
    """
    try:
        docx_parser = HtmlToDocx()
        docx_io = BytesIO()
        doc = Document()
        
        # HtmlToDocx adds content to existing document
        docx_parser.add_html_to_document(request.html_content, doc)
        doc.save(docx_io)
        docx_io.seek(0)
        
        return Response(
            content=docx_io.getvalue(),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": "attachment; filename=legal_document.docx"}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DOCX generation error: {str(e)}")


# --- Voice Endpoints ---

@app.post("/tts")
async def text_to_speech(request: TTSRequest):
    """
    Generates audio from text using Edge-TTS (Neural Voices).
    Returns an MP3 stream.
    """
    try:
        communicate = edge_tts.Communicate(request.text, request.voice,rate="+10%")
        
        # Create a generator that yields audio chunks
        async def audio_generator():
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    yield chunk["data"]
                    
        return StreamingResponse(
            audio_generator(),
            media_type="audio/mpeg",
            headers={"Content-Disposition": "attachment; filename=speech.mp3"}
        )
    except Exception as e:
        print(f"TTS Error: {e}")
        raise HTTPException(status_code=500, detail=f"TTS error: {str(e)}")


@app.post("/stt", response_model=STTResponse)
async def speech_to_text(file: UploadFile = File(...)):
    """
    Transcribes uploaded audio file using Whisper.
    Accepts WAV, MP3, WEBM, etc.
    """
    try:
        model = get_whisper_model()
        
        # Save uploaded file to temp file (Whisper needs a file path usually)
        suffix = os.path.splitext(file.filename)[1] if file.filename else ".tmp"
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp_file:
            content = await file.read()
            tmp_file.write(content)
            tmp_path = tmp_file.name
            
        try:
            # Transcribe
            segments, info = model.transcribe(tmp_path, beam_size=5)
            
            # Combine segments
            text = " ".join([segment.text for segment in segments]).strip()
            
            return STTResponse(text=text)
        finally:
            # Clean up temp file
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
                
    except Exception as e:
        print(f"STT Error: {e}")
        raise HTTPException(status_code=500, detail=f"STT error: {str(e)}")


# --- Legacy Endpoint Support ---
# Keep /run endpoint for backward compatibility

class LegacyPartModel(BaseModel):
    text: Optional[str] = None


class LegacyContentModel(BaseModel):
    role: str
    parts: list[LegacyPartModel]


class LegacyRunRequest(BaseModel):
    """Legacy request format for backward compatibility."""
    appName: str
    userId: str
    sessionId: str
    newMessage: LegacyContentModel
    streaming: bool = False


@app.post("/run")
async def legacy_run_agent(request: LegacyRunRequest):
    """
    Legacy endpoint for backward compatibility with existing frontend.
    
    Converts the old request format to the new chat endpoint format.
    """
    # Extract message text from parts
    message_text = ""
    for part in request.newMessage.parts:
        if part.text:
            message_text += part.text + "\n"
    
    message_text = message_text.strip()
    
    if not message_text:
        raise HTTPException(status_code=400, detail="Empty message content")
    
    # Use the session ID from the request
    session_id = request.sessionId
    
    try:
        # Get chat history for this session
        chat_history = session_memory.get_history(session_id)
        
        # Prepare messages - Default to Legal Notice since legacy doesn't support selection
        messages = [SystemMessage(content=get_system_message("legal_notice"))]
        messages.extend(chat_history)
        messages.append(HumanMessage(content=message_text))
        
        # Run the agent
        # We don't pass issue_type here, so it relies on the system message we just added
        result = await agent.ainvoke({"messages": messages})
        
        # Extract the response from the last AI message
        response_text = ""
        result_messages = result["messages"]
        for msg in reversed(result_messages):
            if isinstance(msg, AIMessage) and msg.content:
                response_text = msg.content
                break
        
        # Update session memory
        session_memory.add_user_message(session_id, message_text)
        session_memory.add_ai_message(session_id, response_text)
        
        # Return in legacy format
        return {
            "events": [],
            "response": response_text,
            "sessionId": session_id,
        }
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


# --- Main Entry Point ---

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=settings.HOST, port=settings.PORT)
