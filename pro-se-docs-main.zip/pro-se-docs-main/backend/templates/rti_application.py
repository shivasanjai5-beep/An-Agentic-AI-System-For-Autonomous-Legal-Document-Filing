
RTI_APPLICATION_HTML = """
<!DOCTYPE html>
<html>
<head>
    <style>
        @page {
            size: A4;
            margin: 2.5cm;
        }
        body { 
            font-family: Helvetica, Arial, sans-serif;
            line-height: 1.4; 
            font-size: 14pt;
        }
        p {
            margin-top: 0;
            margin-bottom: 10px;
        }
        .header { 
            text-align: center; 
            margin-bottom: 30px;
            font-weight: bold; 
            text-decoration: underline; 
            font-size: 16pt;
        }
        .section-label {
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 5px;
        }
        .content-block {
            margin-left: 20px;
            margin-bottom: 15px;
        }
        
        /* Signature section */
        .signature-table {
            width: 100%;
            margin-top: 40px;
        }
        .signature-cell {
            vertical-align: top;
        }
        .right-align {
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="header">APPLICATION UNDER RIGHT TO INFORMATION ACT, 2005</div>

    <p><strong>To,</strong></p>
    <p>The Public Information Officer (PIO) / Assistant Public Information Officer (APIO),</p>
    <div class="content-block">
        {{ department_name }}<br>
        {{ department_address }}
    </div>

    <div class="section-label">1. Name of the Applicant:</div>
    <div class="content-block">{{ applicant_name }}</div>

    <div class="section-label">2. Full Address of the Applicant:</div>
    <div class="content-block">
        {{ applicant_address }}<br>
        Phone: {{ applicant_phone }}<br>
        Email: {{ applicant_email }}
    </div>

    <div class="section-label">3. Particulars of Information Required:</div>
    <div class="content-block">
        <p><strong>(i) Subject matter of information:</strong></p>
        <p>{{ subject_matter }}</p>
        
        <p><strong>(ii) Period to which the information relates:</strong></p>
        <p>{{ period_of_info }}</p>
        
        <p><strong>(iii) Description of the information required:</strong></p>
        <div style="white-space: pre-wrap;">{{ information_sought }}</div>
    </div>

    <div class="section-label">4. Format in which information is required:</div>
    <div class="content-block">
        {{ preferred_format }} (Certified Copies / Inspection of Records / Electronic)
    </div>

    <div class="section-label">5. Whether the Applicant belongs to BPL Category:</div>
    <div class="content-block">
        {{ bpl_status }} (Yes/No)<br>
        <span style="font-size: 0.9em;">(If Yes, please attach photocopy of BPL Card)</span>
    </div>

    <div class="section-label">6. Details of Fee Payment:</div>
    <div class="content-block">
        <p>I am enclosing the application fee of Rs. {{ fee_amount }} by way of {{ payment_mode }} bearing No. {{ payment_details }} dated {{ payment_date }}.</p>
        <p><em>(Note: IPO/Demand Draft/Court Fee Stamp are common modes. Fee is usually Rs. 10 for Central Govt)</em></p>
    </div>

    <div class="content" style="margin-top: 20px;">
        <p>I state that the information sought does not fall within the restrictions contained in Section 8 and 9 of the RTI Act and to the best of my knowledge it pertains to your office.</p>
    </div>

    <table class="signature-table">
        <tr>
            <td class="signature-cell">
                <p>Place: {{ place }}</p>
                <p>Date: {{ date }}</p>
            </td>
            <td class="signature-cell right-align">
                <p>_______________________</p>
                <p>({{ applicant_name }})</p>
                <p>Signature of Applicant</p>
            </td>
        </tr>
    </table>
</body>
</html>
"""

REQUIRED_FIELDS = {
    "department_name": "Name of the Government Department/Public Authority",
    "department_address": "Address of the Department",
    "applicant_name": "Full Name of the Applicant",
    "applicant_address": "Full Address for correspondence",
    "applicant_phone": "Contact Number",
    "applicant_email": "Email Address (Optional)",
    "subject_matter": "Brief subject of the information sought",
    "period_of_info": "Time period (e.g., Jan 2023 to Dec 2023)",
    "information_sought": "Specific questions or details requested (point-wise)",
    "preferred_format": "How you want the info (e.g., Certified Copies, Email)",
    "bpl_status": "Are you Below Poverty Line? (Yes/No)",
    "fee_amount": "Application Fee Amount (e.g., 10)",
    "payment_mode": "Mode of Payment (e.g., Indian Postal Order, Demand Draft)",
    "payment_details": "IPO/DD Number",
    "payment_date": "Date of Payment Instrument",
    "place": "Place of application",
    "date": "Date of application"
}

