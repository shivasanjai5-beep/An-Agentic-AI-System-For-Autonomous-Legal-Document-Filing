"""
Template for Residential Rental Agreement.
"""

REQUIRED_FIELDS = {
    "landlord_name": "Full name of the Landlord (Owner)",
    "landlord_father": "Landlord's father's name",
    "landlord_address": "Landlord's residential address",
    "tenant_name": "Full name of the Tenant",
    "tenant_father": "Tenant's father's name",
    "tenant_address": "Tenant's permanent address",
    "property_address": "Full address of the rented property",
    "lease_start_date": "Date when lease starts (e.g., '1st January 2025')",
    "lease_duration": "Duration of lease in months (usually 11 months)",
    "monthly_rent": "Monthly rent amount in Rupees",
    "security_deposit": "Security deposit amount in Rupees",
    "notice_period": "Notice period for termination (e.g., '1 month')",
    "agreement_date": "Date of agreement signing",
    "place": "City/Place of agreement",
}

RENTAL_AGREEMENT_HTML = """
<!DOCTYPE html>
<html>
<head>
<style>
    body { font-family: 'Times New Roman', serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 40px; }
    h2 { text-align: center; text-transform: uppercase; text-decoration: underline; }
    .content { text-align: justify; }
    .parties { margin: 20px 0; }
    .clause { margin-bottom: 15px; }
    .signatures { margin-top: 80px; display: flex; justify-content: space-between; }
    .witnesses { margin-top: 40px; }
</style>
</head>
<body>

<h2>RENTAL AGREEMENT</h2>

<div class="content">
    <p>This Rental Agreement is made and executed at <strong>{{ place }}</strong> on this <strong>{{ agreement_date }}</strong> by and between:</p>

    <div class="parties">
        <p><strong>{{ landlord_name }}</strong>, S/o {{ landlord_father }}, residing at {{ landlord_address }} (hereinafter called the <strong>"LESSOR"</strong> or "OWNER", which expression shall include his/her heirs, successors, and assigns) of the ONE PART.</p>
        
        <p style="text-align: center; font-weight: bold;">AND</p>

        <p><strong>{{ tenant_name }}</strong>, S/o {{ tenant_father }}, residing at {{ tenant_address }} (hereinafter called the <strong>"LESSEE"</strong> or "TENANT", which expression shall include his/her heirs, successors, and assigns) of the OTHER PART.</p>
    </div>

    <p>WHEREAS the Lessor is the absolute owner of the property situated at <strong>{{ property_address }}</strong>.</p>

    <p>AND WHEREAS the Lessee has requested the Lessor to let out the said property for residential purposes, and the Lessor has agreed to let out the same on the following terms and conditions:</p>

    <h3>NOW THIS DEED WITNESSETH AS FOLLOWS:</h3>

    <div class="clause">
        1. <strong>Duration:</strong> The lease shall be for a period of <strong>{{ lease_duration }} months</strong> commencing from {{ lease_start_date }}.
    </div>

    <div class="clause">
        2. <strong>Rent:</strong> The Lessee shall pay a monthly rent of <strong>Rs. {{ monthly_rent }}/-</strong>. The rent shall be paid on or before the 5th of every succeeding English calendar month.
    </div>

    <div class="clause">
        3. <strong>Security Deposit:</strong> The Lessee has paid an interest-free refundable security deposit of <strong>Rs. {{ security_deposit }}/-</strong> to the Lessor. This amount shall be refunded at the time of vacating the premises, subject to deductions for damages or arrears.
    </div>

    <div class="clause">
        4. <strong>Maintenance:</strong> The Lessee shall pay electricity and water charges as per the meter reading/bills.
    </div>

    <div class="clause">
        5. <strong>Purpose:</strong> The premises shall be used for residential purposes only. The Lessee shall not sublet the premises.
    </div>

    <div class="clause">
        6. <strong>Termination:</strong> Either party can terminate this agreement by giving <strong>{{ notice_period }}</strong> notice in writing.
    </div>

    <div class="clause">
        7. <strong>Good Condition:</strong> The Lessee shall keep the premises in good and tenantable condition and shall not cause any structural changes.
    </div>

    <div class="clause">
        8. <strong>Inspection:</strong> The Lessor shall have the right to inspect the premises at reasonable times with prior notice.
    </div>
</div>

<div class="signatures">
    <div>
        ____________________<br>
        <strong>LESSOR (OWNER)</strong>
    </div>
    <div style="text-align: right;">
        ____________________<br>
        <strong>LESSEE (TENANT)</strong>
    </div>
</div>

<div class="witnesses">
    <p><strong>WITNESSES:</strong></p>
    <br>
    1. ____________________
    <br><br>
    2. ____________________
</div>

</body>
</html>
"""

