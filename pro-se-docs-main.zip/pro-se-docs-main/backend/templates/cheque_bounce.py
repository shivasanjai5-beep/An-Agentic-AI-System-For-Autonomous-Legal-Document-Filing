
CHEQUE_BOUNCE_HTML = """
<!DOCTYPE html>
<html>
<head>
    <style>
        @page {
            size: A4;
            margin: 2.5cm;
        }
        body { 
            font-family: Helvetica, Arial, sans-serif;
            line-height: 1.4; 
            font-size: 14pt;
        }
        p {
            margin-top: 0;
            margin-bottom: 10px;
        }
        .header { 
            text-align: center; 
            margin-bottom: 20px;
            font-weight: bold; 
            text-transform: uppercase; 
            text-decoration: underline; 
            font-size: 16pt;
        }
        .meta { margin-bottom: 20px; }
        .recipient { margin-bottom: 20px; }
        .subject { font-weight: bold; margin: 20px 0; text-align: justify; }
        .content { margin-bottom: 20px; text-align: justify; }
        
        /* Signature section */
        .signature-table {
            width: 100%;
            margin-top: 40px;
        }
        .signature-cell {
            vertical-align: top;
        }
    </style>
</head>
<body>
    <div class="header">LEGAL NOTICE</div>
    <div style="text-align: center; font-weight: bold; margin-bottom: 20px;">(Under Section 138 of the Negotiable Instruments Act, 1881)</div>

    <div class="meta">
        <p><strong>Date:</strong> {{ date }}</p>
        <p><strong>From:</strong><br>
        {{ payee_name }}<br>
        {{ payee_address }}</p>
        <p><strong>Through Advocate:</strong><br>
        {{ advocate_name }}<br>
        {{ advocate_address }}</p>
    </div>

    <div class="recipient">
        <p><strong>To,</strong><br>
        {{ drawer_name }}<br>
        {{ drawer_address }}</p>
    </div>

    <div class="subject">
        <strong>Subject:</strong> Statutory Notice under Section 138 of the Negotiable Instruments Act, 1881, regarding dishonor of Cheque No. {{ cheque_number }} dated {{ cheque_date }} for Rs. {{ amount }}.
    </div>

    <div class="content">
        <p>Dear Sir/Madam,</p>

        <p>Under the instruction and authority from my client, <strong>{{ payee_name }}</strong>, I hereby serve upon you the following legal notice:</p>

        <p>1. That you had issued a Cheque bearing No. <strong>{{ cheque_number }}</strong> dated <strong>{{ cheque_date }}</strong> for a sum of <strong>Rs. {{ amount }}</strong> drawn on <strong>{{ bank_name }}</strong> in favor of my client towards the discharge of your legally enforceable debt/liability regarding {{ transaction_details }}.</p>

        <p>2. That my client presented the said cheque for encashment through their banker, but to the shock and surprise of my client, the said cheque was returned unpaid/dishonored with the remarks <strong>"{{ return_reason }}"</strong> vide Return Memo dated <strong>{{ return_date }}</strong>.</p>

        <p>3. That by your act of issuing a cheque without maintaining sufficient funds or for other reasons, you have committed an offense punishable under Section 138 of the Negotiable Instruments Act, 1881, as amended up to date.</p>

        <p>4. That through this notice, I hereby call upon you to make the payment of the cheque amount of <strong>Rs. {{ amount }}</strong> to my client within <strong>15 (fifteen) days</strong> from the receipt of this notice.</p>

        <p>5. That failing which, my client shall be constrained to initiate appropriate legal proceedings against you, including filing a criminal complaint under Section 138 of the N.I. Act, entirely at your risk, cost, and consequences. You shall also be liable to pay the cost of this legal notice.</p>
        
        <p>Copy of this notice is retained in my office for further record.</p>
    </div>

    <table class="signature-table">
        <tr>
            <td class="signature-cell">
                <p>Sincerely,</p>
                <br>
                <p>_______________________<br>
                (Signature)</p>
                <p>{{ advocate_name }}<br>
                Advocate</p>
            </td>
        </tr>
    </table>
</body>
</html>
"""

REQUIRED_FIELDS = {
    "payee_name": "Name of the person who received the cheque (Complainant)",
    "payee_address": "Address of the Payee",
    "advocate_name": "Name of the Advocate sending the notice",
    "advocate_address": "Office Address of the Advocate",
    "drawer_name": "Name of the person who issued the cheque (Accused)",
    "drawer_address": "Address of the Drawer",
    "cheque_number": "6-digit Cheque Number",
    "cheque_date": "Date mentioned on the Cheque",
    "amount": "Cheque Amount (e.g., 50,000)",
    "bank_name": "Name of the Bank and Branch where cheque was drawn",
    "transaction_details": "Reason for payment (e.g., repayment of loan, purchase of goods)",
    "return_reason": "Reason for bounce as per memo (e.g., Insufficient Funds)",
    "return_date": "Date on the Return Memo from Bank",
    "date": "Date of sending this notice (Must be within 30 days of return memo)"
}

