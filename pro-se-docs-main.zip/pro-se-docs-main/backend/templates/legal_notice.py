
LEGAL_NOTICE_HTML = """
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: 'Times New Roman', Times, serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 40px; }
        .header { text-align: center; margin-bottom: 40px; font-weight: bold; text-transform: uppercase; text-decoration: underline; }
        .meta { margin-bottom: 30px; }
        .recipient { margin-bottom: 20px; }
        .subject { font-weight: bold; margin: 20px 0; }
        .content { margin-bottom: 40px; text-align: justify; }
        .signature { margin-top: 60px; }
        .footer { margin-top: 40px; font-size: 0.9em; color: #666; border-top: 1px solid #ccc; padding-top: 10px; }
    </style>
</head>
<body>
    <div class="header">LEGAL NOTICE</div>

    <div class="meta">
        <p>Date: {{ date }}</p>
        <p>From:<br>
        {{ sender_name }}<br>
        {{ sender_address }}</p>
    </div>

    <div class="recipient">
        <p>To,<br>
        {{ recipient_name }}<br>
        {{ recipient_address }}</p>
    </div>

    <div class="subject">
        Subject: Legal Notice for {{ subject_matter }}
    </div>

    <div class="content">
        <p>Dear Sir/Madam,</p>

        <p>Under the instruction and authority from my client, <strong>{{ sender_name }}</strong>, resident of {{ sender_address }}, I do hereby serve upon you the following legal notice:</p>

        <div style="white-space: pre-wrap;">{{ notice_content }}</div>
        
        <p>I, therefore, call upon you through this legal notice to {{ demand_action }} within {{ notice_period }} days from the receipt of this notice, failing which my client shall be constrained to initiate appropriate legal proceedings against you in the competent court of law entirely at your risk, cost, and consequences.</p>
    </div>

    <div class="signature">
        <p>Sincerely,</p>
        <br>
        <p>_______________________<br>
        (Signature)</p>
        <p>{{ advocate_name }}<br>
        Advocate</p>
    </div>
</body>
</html>
"""

REQUIRED_FIELDS = {
    "sender_name": "Name of the person sending the notice",
    "sender_address": "Full address of the sender",
    "recipient_name": "Name of the person receiving the notice",
    "recipient_address": "Full address of the recipient",
    "subject_matter": "Brief subject of the legal notice",
    "notice_content": "Detailed content/body of the notice explaining the grievance",
    "demand_action": "Specific action demanded from the recipient",
    "notice_period": "Time period given to comply (e.g., 15, 30)",
    "date": "Date of the notice",
    "advocate_name": "Name of the advocate (or 'Self' if sending personally)"
}









