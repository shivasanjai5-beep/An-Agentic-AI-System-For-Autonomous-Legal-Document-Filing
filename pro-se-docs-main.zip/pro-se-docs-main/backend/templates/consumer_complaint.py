
CONSUMER_COMPLAINT_HTML = """
<!DOCTYPE html>
<html>
<head>
    <style>
        @page {
            size: A4;
            margin: 2.5cm;
        }
        body { 
            font-family: Helvetica, Arial, sans-serif;
            line-height: 1.4; 
            font-size: 14pt;
        }
        p {
            margin-top: 0;
            margin-bottom: 10px;
        }
        .header { 
            text-align: center; 
            margin-bottom: 20px;
            font-weight: bold; 
            text-transform: uppercase; 
            text-decoration: underline; 
            font-size: 16pt;
        }
        .court-title {
            text-align: center;
            font-weight: bold;
            margin-bottom: 30px;
            text-transform: uppercase;
        }
        .case-details {
            margin-bottom: 20px;
        }
        .party-section {
            margin-bottom: 15px;
        }
        .subject {
            font-weight: bold;
            margin: 20px 0;
            text-align: justify;
        }
        .content { 
            margin-bottom: 20px; 
            text-align: justify; 
        }
        .prayer {
            margin-top: 20px;
            margin-bottom: 30px;
            font-weight: bold;
        }
        .verification {
            margin-top: 40px;
        }
        
        /* Signature section */
        .signature-table {
            width: 100%;
            margin-top: 50px;
        }
        .signature-cell {
            vertical-align: top;
            width: 50%;
        }
        .right-align {
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="court-title">
        BEFORE THE DISTRICT CONSUMER DISPUTES REDRESSAL COMMISSION<br>
        AT {{ district_name }}
    </div>

    <div class="case-details">
        <p><strong>Complaint Case No.:</strong> ________ / {{ current_year }}</p>
    </div>

    <div class="party-section">
        <p><strong>IN THE MATTER OF:</strong></p>
        <p>
            {{ complainant_name }}<br>
            S/o / D/o {{ complainant_parent_name }}<br>
            R/o {{ complainant_address }}
        </p>
        <p class="right-align">... Complainant</p>
    </div>

    <div class="party-section">
        <p style="text-align: center;"><strong>VERSUS</strong></p>
        <p>
            {{ opposite_party_name }}<br>
            {{ opposite_party_address }}
        </p>
        <p class="right-align">... Opposite Party</p>
    </div>

    <div class="subject">
        SUBJECT: COMPLAINT UNDER SECTION 35 OF THE CONSUMER PROTECTION ACT, 2019
    </div>

    <div class="content">
        <p><strong>MOST RESPECTFULLY SHOWETH:</strong></p>

        <p>1. That the Complainant is a consumer as defined under the Consumer Protection Act, 2019, having purchased goods/hired services for consideration.</p>

        <p>2. That the Complainant purchased/hired {{ product_service_name }} from the Opposite Party vide Invoice/Receipt No. {{ invoice_number }} dated {{ purchase_date }} for a sum of Rs. {{ amount_paid }}.</p>

        <p>3. That the brief facts of the case are as follows:</p>
        <div style="white-space: pre-wrap; margin-bottom: 15px;">{{ complaint_details }}</div>

        <p>4. That the Complainant approached the Opposite Party multiple times regarding the {{ defect_deficiency_type }} but the Opposite Party failed to resolve the issue.</p>

        <p>5. That the Opposite Party has been deficient in providing service / sold defective goods and has also indulged in unfair trade practices, causing mental agony and financial loss to the Complainant.</p>

        <p>6. That the cause of action arose on {{ purchase_date }} when the transaction took place and subsequently on various dates when the Complainant approached the Opposite Party.</p>

        <p>7. That this Hon'ble Commission has the territorial and pecuniary jurisdiction to entertain and try this complaint.</p>
    </div>

    <div class="prayer">
        <p>PRAYER:</p>
        <p>It is, therefore, most respectfully prayed that this Hon'ble Commission may be pleased to direct the Opposite Party to:</p>
        <div style="white-space: pre-wrap;">{{ relief_sought }}</div>
        <p>Any other relief which this Hon'ble Commission deems fit and proper in the interest of justice.</p>
    </div>

    <table class="signature-table">
        <tr>
            <td class="signature-cell">
                <p>Place: {{ place }}</p>
                <p>Date: {{ date }}</p>
            </td>
            <td class="signature-cell right-align">
                <p>_______________________</p>
                <p>({{ complainant_name }})</p>
                <p>Complainant</p>
            </td>
        </tr>
    </table>

    <div class="verification">
        <p style="text-align: center; font-weight: bold; text-decoration: underline;">VERIFICATION</p>
        <p>I, {{ complainant_name }}, the Complainant herein, do hereby verify that the contents of paragraphs 1 to 7 are true to my personal knowledge and belief and nothing material has been concealed therefrom.</p>
        
        <table class="signature-table">
            <tr>
                <td class="signature-cell">
                    <p>Place: {{ place }}</p>
                    <p>Date: {{ date }}</p>
                </td>
                <td class="signature-cell right-align">
                    <p>_______________________</p>
                    <p>({{ complainant_name }})</p>
                    <p>Complainant</p>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>
"""

REQUIRED_FIELDS = {
    "district_name": "Name of the District where the Consumer Forum is located",
    "current_year": "Current Year (e.g., 2024)",
    "complainant_name": "Full Name of the Complainant (Consumer)",
    "complainant_parent_name": "Father's or Husband's Name of the Complainant",
    "complainant_address": "Full Address of the Complainant",
    "opposite_party_name": "Name of the Shop/Company/Service Provider",
    "opposite_party_address": "Address of the Opposite Party",
    "product_service_name": "Name of the Product purchased or Service hired",
    "invoice_number": "Bill/Invoice/Receipt Number",
    "purchase_date": "Date of Purchase/Hiring",
    "amount_paid": "Amount paid for the product/service",
    "complaint_details": "Detailed description of the grievance/defect/deficiency",
    "defect_deficiency_type": "Type of issue (e.g., 'manufacturing defect', 'deficiency in service')",
    "relief_sought": "What you want the court to order (e.g., Refund Rs. X, Pay Compensation Rs. Y)",
    "place": "Place where the complaint is being signed",
    "date": "Date of signing the complaint"
}

